import cv2
import os

for i, filename in enumerate(os.listdir('./new_img')):
    print(filename, '%.3d' % i)
    img = cv2.imread('./new_img/' + filename)
    print(img.shape)
    img = cv2.resize(img, (512,512), interpolation = cv2.INTER_AREA)
    cv2.imwrite('./img/%.3d.jpg' % i, img)